package com.jspider.factorydesignpattern.snacks;

public interface snacks {
	
	
	
	

}

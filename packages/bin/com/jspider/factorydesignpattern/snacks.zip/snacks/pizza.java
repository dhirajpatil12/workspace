package com.jspider.factorydesignpattern.snacks;

public class pizza {
	void mypizza  (String pizzas){
	
	System.out.println("i like to eat pizza as a snacks");

}
}

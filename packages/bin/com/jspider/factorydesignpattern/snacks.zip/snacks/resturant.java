package com.jspider.factorydesignpattern.snacks;

public class resturant {
	resturant obj=new resturant();
	obj.mypizza();
    obj.mysandwich();
    obj.myfries();
    obj.mymomos();
    obj.mypizza();
	

}

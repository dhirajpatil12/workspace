package com.jspider.factorydesignpattern.snacks;

public class burger {
	void myburger(String burgers)
	System.out.println("i like to eat burger as a snacks");

}

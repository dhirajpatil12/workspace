package com.jspider.factorydesignpattern.snacks;

public class sandwich {
	void mysandwich(String sandwichs )
	System.out.println("i like to eat sandwich as a snacks");

}

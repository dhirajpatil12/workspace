package com.jspider.factorydesignpattern.snacks;

public class momos {
	void myburger(String burgers)
	System.out.println("i like to eat momo as a snacks");

}

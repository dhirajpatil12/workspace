package com.jspider.factorydesignpattern.snacks;

public class fries {
	void myfries(String friess)
	System.out.println("i like to eat french fries as a snacks")

}

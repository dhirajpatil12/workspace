package com.jspider.factorydesignpattern.builder;

public class carbuilder {

	String name;
	String color;
	long price;
	float mileage;
	String fuel;
	String type;
	 
	public carbuilder name(String name) {
		this.name=name;
		return this;
		
	}
	
	public carbuilder color(String color) {
		this.color=color;
		return this;
	}
	
	public carbuilder price(long price) {
		this.price=price;
		return this;
	}
	public carbuilder mileage(float mileage) {
		this.mileage=mileage;
		return this;
	}
	public carbuilder fuel(String fuel) {
		this.fuel=fuel;
		return this;
	}
	public carbuilder type(String type) {
		this.type=type;
		return this;
	}
	]
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
